import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold text-white mb-4">
        React + Tailwind Setup
      </h1>
      <p className="text-lg text-sky-400">
        Your app is now ready! ✨
      </p>
    </div>
  );
}

export default App;